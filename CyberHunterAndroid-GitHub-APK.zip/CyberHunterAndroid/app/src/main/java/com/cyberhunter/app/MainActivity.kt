package com.cyberhunter.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.CopyOnWriteArrayList

class MainActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var scanButton: Button
    private val seen = CopyOnWriteArrayList<String>()
    private var scanning = false
    private var bleCallback: ScanCallback? = null
    private val reqCode = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 10, 10)
        window.navigationBarColor = android.graphics.Color.rgb(5, 10, 10)
        buildUi()
    }

    private fun buildUi() {
        val bg = android.graphics.Color.rgb(5, 10, 10)
        val neon = android.graphics.Color.rgb(0, 229, 168)
        val white = android.graphics.Color.rgb(220, 245, 238)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "CYBER HUNTER  /  DEVICE LAB"
            textSize = 22f
            setTextColor(neon)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Authorized diagnostics • Android"
            textSize = 12f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        layout.addView(title)
        layout.addView(sub)
        layout.addView(makeButton("NETWORK STATUS") { showNetworkInfo() })
        scanButton = makeButton("SCAN NEARBY BLE DEVICES") { startBleScan() }
        layout.addView(scanButton)
        layout.addView(makeButton("RADIO LAB / USB-OTG") {
            append("\nRADIO LAB\nGeneric Android phones cannot transmit or decode every radio frequency by themselves.\nConnect only a supported, documented USB-OTG device. This build does not capture, clone, or replay access-control signals.")
        })
        layout.addView(makeButton("TELEGRAM CONTROL SETUP") {
            append("\nTELEGRAM CONTROL\nThis APK does not contain a bot token or remote-command server.\nFor a real integration, use a private bot + authenticated backend. Never put a bot token directly in a public APK.")
        })
        layout.addView(makeButton("CLEAR LOG") { output.text = ">> CYBER HUNTER READY\n" })
        output = TextView(this).apply {
            text = ">> CYBER HUNTER READY\n"
            textSize = 13f
            setTextColor(neon)
            setPadding(4, 18, 4, 4)
            typeface = android.graphics.Typeface.MONOSPACE
        }
        val scroll = ScrollView(this)
        scroll.addView(output)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(android.graphics.Color.rgb(0, 229, 168))
            setBackgroundColor(android.graphics.Color.rgb(13, 30, 28))
            setPadding(10, 8, 10, 8)
            val p = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.setMargins(0, 5, 0, 5)
            layoutParams = p
            setOnClickListener { action() }
        }
    }

    private fun append(s: String) {
        runOnUiThread { output.append("\n$s\n") }
    }

    private fun showNetworkInfo() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val active = cm.activeNetwork
        val caps = active?.let { cm.getNetworkCapabilities(it) }
        val type = when {
            caps == null -> "Disconnected"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other network"
        }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = try { Formatter.formatIpAddress(wm.connectionInfo.ipAddress) } catch (_: Exception) { "Unavailable" }
        append("NETWORK STATUS\nConnection: $type\nLocal IP: $ip\nNote: Android may restrict Wi-Fi details depending on version and permissions.")
    }

    private fun hasBlePermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun startBleScan() {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            append("BLE is not supported on this device.")
            return
        }
        if (!hasBlePermissions()) {
            val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermissions(perms, reqCode)
            append("Allow the requested Bluetooth permission, then tap scan again.")
            return
        }
        try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null || !adapter.isEnabled) {
                append("Turn Bluetooth on, then scan again.")
                return
            }
            val scanner = adapter.bluetoothLeScanner
            if (scanning) {
                bleCallback?.let { scanner.stopScan(it) }
                scanning = false
                scanButton.text = "SCAN NEARBY BLE DEVICES"
                append("BLE scan stopped.")
                return
            }
            seen.clear()
            scanning = true
            scanButton.text = "STOP BLE SCAN"
            append("Scanning nearby BLE advertisements for 12 seconds...")
            val callback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    val deviceName = try { result.device.name ?: "Unnamed BLE device" } catch (_: SecurityException) { "Name permission unavailable" }
                    val item = "$deviceName | RSSI ${result.rssi} dBm"
                    if (!seen.contains(item)) {
                        seen.add(item)
                        append(item)
                    }
                }
                override fun onScanFailed(errorCode: Int) {
                    append("BLE scan failed: code $errorCode")
                    scanning = false
                    scanButton.text = "SCAN NEARBY BLE DEVICES"
                }
            }
            bleCallback = callback
            scanner.startScan(callback)
            scanButton.postDelayed({
                try { scanner.stopScan(callback) } catch (_: Exception) {}
                scanning = false
                scanButton.text = "SCAN NEARBY BLE DEVICES"
                append("Scan complete. Found ${seen.size} distinct name/RSSI entries.\nBLE results do not identify every nearby phone or computer.")
            }, 12000)
        } catch (e: SecurityException) {
            append("Permission denied: ${e.message}")
        } catch (e: Exception) {
            append("Scan error: ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqCode) {
            append(if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })
                "Permissions granted. Tap BLE scan again." else "Required permission was not granted.")
        }
    }
}
