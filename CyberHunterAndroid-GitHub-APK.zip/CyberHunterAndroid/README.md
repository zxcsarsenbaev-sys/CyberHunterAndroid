# CYBER HUNTER Android starter

This is a native Android Studio project source, not a prebuilt APK. The current environment has no Android SDK/Gradle installation, so an APK has not been built or tested here.

## Included
- Native Android UI
- Current network connection and local IP diagnostics (subject to Android restrictions)
- BLE advertisement scanning with runtime permissions
- Safe Radio Lab notes for supported USB-OTG hardware
- Telegram integration setup guidance

## Not included / important limits
- No arbitrary computer control, remote app closing, SMS access, or file deletion.
- No RF capture/replay, access-card cloning, or Wi-Fi password cracking.
- Telegram bot token is not embedded in the app. A real bot integration should use a private backend and authenticated commands.
- BLE scan does not discover every phone/computer; devices may not advertise or may hide their names.
- Wi-Fi scanning and USB radio support depend on Android version, hardware, permissions, and device-specific APIs.

## Build APK
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open this folder as a project.
3. Allow Gradle sync.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

For command-line build, install a compatible Gradle distribution and Android SDK, then run:
`gradle assembleDebug`

The APK must be built and tested on a real device before relying on it.
